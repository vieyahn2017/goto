# Go-patterns-with-channel

 Go语言信道和goroutine的一些设计模式的简单例子。

 这些设计模式和应用场景的介绍在http://hit9.org/post/2013-11-18-14-57.html
